from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Field, Fieldset, Div, HTML
from .models import Employee, KitInspection, Customer, Product, SolderPasteInspection, FirstOffBoardInspection, LastBoardProducedInspection, Wastage, Job_number

class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Employee Details',
                Field('user', css_class='form-control'),
                Field('name', css_class='form-control'),
                Field('role', css_class='form-control'),
                Field('photo', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

    def clean(self):
        cleaned_data = super().clean()
        user = cleaned_data.get('user')
        if user and Employee.objects.filter(user=user).exists():
            raise forms.ValidationError('An employee for this user already exists.')
        return cleaned_data

class CustomerForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Customer Details',
                Field('name', css_class='form-control'),
                Field('details', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Product Details',
                Field('customer', css_class='form-control'),
                Field('job_no', css_class='form-control'),
                Field('product_ID', css_class='form-control'),
                Field('rev_number', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

class KitInspectionForm(forms.ModelForm):
    class Meta:
        model = KitInspection
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Kit Inspection Details',
                Field('customer', css_class='form-control'),
                Field('product', css_class='form-control'),
                Field('quantity', css_class='form-control'),
                Field('kit_inspector', css_class='form-control'),
                Field('barcode_scanning_enabled', css_class='form-check-input'),
                Field('photo', css_class='form-control'),
                Field('job_no', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

class SolderPasteInspectionForm(forms.ModelForm):
    class Meta:
        model = SolderPasteInspection
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Solder Paste Inspection Details',
                Field('customer', css_class='form-control'),
                Field('product', css_class='form-control'),
                Field('paste_type', css_class='form-control'),
                Field('paste_inspector', css_class='form-control'),
                Field('barcode_scanning_enabled', css_class='form-check-input'),
                Field('photo', css_class='form-control'),
                Field('job_no', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

class FirstOffBoardInspectionForm(forms.ModelForm):
    class Meta:
        model = FirstOffBoardInspection
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'First Off Board Inspection Details',
                Field('customer', css_class='form-control'),
                Field('product', css_class='form-control'),
                Field('roaming_qc_name', css_class='form-control'),
                Field('barcode_scanning_enabled', css_class='form-check-input'),
                Field('photo', css_class='form-control'),
                Field('job_no', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

class LastBoardProducedInspectionForm(forms.ModelForm):
    class Meta:
        model = LastBoardProducedInspection
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Last Board Produced Inspection Details',
                Field('customer', css_class='form-control'),
                Field('product', css_class='form-control'),
                Field('quantity_produced', css_class='form-control'),
                Field('setup_operator_name', css_class='form-control'),
                Field('barcode_scanning_enabled', css_class='form-check-input'),
                Field('photo', css_class='form-control'),
                Field('job_no', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

class WastageForm(forms.ModelForm):
    class Meta:
        model = Wastage
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Wastage Details',
                Field('name', css_class='form-control'),
                Field('kit_inspection', css_class='form-control'),
                Field('last_board_produced_inspection', css_class='form-control'),
                Field('calculated_wastage', css_class='form-control'),
                Field('photo', css_class='form-control'),
                Field('job_no', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )

class JobNumberForm(forms.ModelForm):
    class Meta:
        model = Job_number
        fields = '__all__'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.layout = Layout(
            Fieldset(
                'Job Number Details',
                Field('job_number', css_class='form-control'),
            ),
            HTML('<br>'),
            Div(
                HTML('<button type="submit" class="btn btn-primary">Submit</button>'),
                css_class='d-grid gap-2',
            ),
        )