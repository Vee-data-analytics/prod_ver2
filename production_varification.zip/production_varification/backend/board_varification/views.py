from django.shortcuts import render, redirect, get_object_or_404
from .forms import EmployeeForm,ProductForm, CustomerForm, KitInspectionForm, SolderPasteInspectionForm, FirstOffBoardInspectionForm, LastBoardProducedInspectionForm, WastageForm, JobNumberForm
from .models import Employee, Customer, KitInspection, SolderPasteInspection, FirstOffBoardInspection, LastBoardProducedInspection, Wastage, Job_number
from django.shortcuts import render
from .models import Product
from django.shortcuts import render, redirect
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Employee
import cv2
import pyzbar.pyzbar as pyzbar
from django.http import JsonResponse


@csrf_exempt
def qrscanner(request):
    if request.method == 'POST':
        # Check if the request contains a video file
        if 'video' in request.FILES:
            video_file = request.FILES.get('video')

            # Read the video file
            video_bytes = video_file.read()

            # Decode the QR code from the video frame
            decoded = pyzbar.decode(Image.open(io.BytesIO(video_bytes)))

            if decoded:
                qr_data = decoded[0].data.decode('utf-8')

                try:
                    employee = Employee.objects.get(user__username=qr_data)
                    role = employee.role

                    # Redirect based on employee role
                    if role == 'kitter':
                        return JsonResponse({'redirect_url': '/kit-inspections/create/'})
                    elif role == 'setup_operator':
                        return JsonResponse({'redirect_url': '/last-board-produced-inspections/create/'})
                    elif role == 'qc':
                        return JsonResponse({'redirect_url': '/first-off-board-inspections/create/'})
                    elif role == 'paste_inspector':
                        return JsonResponse({'redirect_url': '/solder-paste-inspections/create/'})
                    elif role == 'programmer':
                        return JsonResponse({'redirect_url': '/forms-overview/'})
                    else:
                        return JsonResponse({'redirect_url': '/default-redirect/'}, status=400)
                except Employee.DoesNotExist:
                    return JsonResponse({'error': 'Employee not found'}, status=404)
            else:
                return JsonResponse({'error': 'No QR code detected'}, status=404)
        else:
            return JsonResponse({'error': 'No video file provided'}, status=400)
    else:
        # If not a POST request, just render the QR scanner page
        return render(request, 'QR_scanner.html')

@csrf_exempt
def verify_employee_and_redirect(request):
    if request.method == 'POST':
        # Extract QR code data from the request
        qr_data = request.POST.get('qrData')
        try:
            # Assuming qr_data contains the employee's username
            employee = Employee.objects.get(user__username=qr_data)
            # Determine the redirect URL based on the employee's role
            if employee.role == 'kitter':
                redirect_url = reverse('kit_inspection_create')
            elif employee.role == 'setup_operator':
                redirect_url = reverse('last_board_produced_inspection_create')
            elif employee.role == 'qc':
                redirect_url = reverse('first_off_board_inspection_create')
            elif employee.role == 'paste_inspector':
                redirect_url = reverse('solder_paste_inspection_create')
            elif employee.role == 'programmer':
                redirect_url = reverse('forms_overview')
            else:
                redirect_url = reverse('default_redirect')
            return JsonResponse({'redirect_url': redirect_url})
        except Employee.DoesNotExist:
            return JsonResponse({'error': 'Employee not found'}, status=404)
    else:
        return JsonResponse({'error': 'Invalid request'}, status=400)
        
        
def forms_overview(request):
    # Assuming the user is linked to an employee profile
    employee = request.user.employee
    context = {
        'role': employee.role,
        'is_programmer': employee.role == 'programmer',
        'is_kitter': employee.role == 'kitter',
        'is_setup_operator': employee.role == 'setup_operator',
        'is_qc': employee.role == 'qc',
        'is_paste_inspector': employee.role == 'paste_inspector',
    }
    return render(request, 'forms_overview.html', context)




def product_list(request):
    products = Product.objects.all()
    return render(request, 'product_list.html', {'products': products})

def product_create(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'product_form.html', {'form': form})

def product_update(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('product_list')
    else:
        form = ProductForm(instance=product)
    return render(request, 'app_name/product_form.html', {'form': form})
# Employee Views
def employee_list(request):
    employees = Employee.objects.all()
    return render(request, 'employee_list.html', {'employees': employees})

def employee_create(request):
    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('employee_list')
    else:
        form = EmployeeForm()
    return render(request, 'employee_form.html', {'form': form})

def employee_update(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    if request.method == 'POST':
        form = EmployeeForm(request.POST, request.FILES, instance=employee)
        if form.is_valid():
            form.save()
            return redirect('employee_list')
    else:
        form = EmployeeForm(instance=employee)
    return render(request, 'employee_form.html', {'form': form})

# Customer Views
def customer_list(request):
    customers = Customer.objects.all()
    return render(request, 'customer_list.html', {'customers': customers})

def customer_create(request):
    if request.method == 'POST':
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('customer_list')
    else:
        form = CustomerForm()
    return render(request, 'customer_form.html', {'form': form})

def customer_update(request, pk):
    customer = get_object_or_404(Customer, pk=pk)
    if request.method == 'POST':
        form = CustomerForm(request.POST, instance=customer)
        if form.is_valid():
            form.save()
            return redirect('customer_list')
    else:
        form = CustomerForm(instance=customer)
    return render(request, 'customer_form.html', {'form': form})

# KitInspection Views
def kit_inspection_list(request):
    kit_inspections = KitInspection.objects.all()
    return render(request, 'kit_inspection_list.html', {'kit_inspections': kit_inspections})

def kit_inspection_create(request):
    if request.method == 'POST':
        form = KitInspectionForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('kit_inspection_list')
    else:
        form = KitInspectionForm()
    return render(request, 'kit_inspection_form.html', {'form': form})

def kit_inspection_update(request, pk):
    kit_inspection = get_object_or_404(KitInspection, pk=pk)
    if request.method == 'POST':
        form = KitInspectionForm(request.POST, request.FILES, instance=kit_inspection)
        if form.is_valid():
            form.save()
            return redirect('kit_inspection_list')
    else:
        form = KitInspectionForm(instance=kit_inspection)
    return render(request, 'kit_inspection_form.html', {'form': form})

# SolderPasteInspection Views
def solder_paste_inspection_list(request):
    solder_paste_inspections = SolderPasteInspection.objects.all()
    return render(request, 'solder_paste_inspection_list.html', {'solder_paste_inspections': solder_paste_inspections})

def solder_paste_inspection_create(request):
    if request.method == 'POST':
        form = SolderPasteInspectionForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('solder_paste_inspection_list')
    else:
        form = SolderPasteInspectionForm()
    return render(request, 'solder_paste_inspection_form.html', {'form': form})

def solder_paste_inspection_update(request, pk):
    solder_paste_inspection = get_object_or_404(SolderPasteInspection, pk=pk)
    if request.method == 'POST':
        form = SolderPasteInspectionForm(request.POST, request.FILES, instance=solder_paste_inspection)
        if form.is_valid():
            form.save()
            return redirect('solder_paste_inspection_list')
    else:
        form = SolderPasteInspectionForm(instance=solder_paste_inspection)
    return render(request, 'solder_paste_inspection_form.html', {'form': form})

# FirstOffBoardInspection Views
def first_off_board_inspection_list(request):
    first_off_board_inspections = FirstOffBoardInspection.objects.all()
    return render(request, 'first_off_board_inspection_list.html', {'first_off_board_inspections': first_off_board_inspections})

def first_off_board_inspection_create(request):
    if request.method == 'POST':
        form = FirstOffBoardInspectionForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('first_off_board_inspection_list')
    else:
        form = FirstOffBoardInspectionForm()
    return render(request, 'first_off_board_inspection_form.html', {'form': form})

def first_off_board_inspection_update(request, pk):
    first_off_board_inspection = get_object_or_404(FirstOffBoardInspection, pk=pk)
    if request.method == 'POST':
        form = FirstOffBoardInspectionForm(request.POST, request.FILES, instance=first_off_board_inspection)
        if form.is_valid():
            form.save()
            return redirect('first_off_board_inspection_list')
    else:
        form = FirstOffBoardInspectionForm(instance=first_off_board_inspection)
    return render(request, 'first_off_board_inspection_form.html', {'form': form})

# LastBoardProducedInspection Views
def last_board_produced_inspection_list(request):
    last_board_produced_inspections = LastBoardProducedInspection.objects.all()
    return render(request, 'last_board_produced_inspection_list.html', {'last_board_produced_inspections': last_board_produced_inspections})

def last_board_produced_inspection_create(request):
    if request.method == 'POST':
        form = LastBoardProducedInspectionForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('last_board_produced_inspection_list')
    else:
        form = LastBoardProducedInspectionForm()
    return render(request, 'last_board_produced_inspection_form.html', {'form': form})

def last_board_produced_inspection_update(request, pk):
    last_board_produced_inspection = get_object_or_404(LastBoardProducedInspection, pk=pk)
    if request.method == 'POST':
        form = LastBoardProducedInspectionForm(request.POST, request.FILES, instance=last_board_produced_inspection)
        if form.is_valid():
            form.save()
            return redirect('last_board_produced_inspection_list')
    else:
        form = LastBoardProducedInspectionForm(instance=last_board_produced_inspection)
    return render(request, 'last_board_produced_inspection_form.html', {'form': form})

# Wastage Views
def wastage_list(request):
    wastages = Wastage.objects.all()
    return render(request, 'wastage_list.html', {'wastages': wastages})

def wastage_create(request):
    if request.method == 'POST':
        form = WastageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('wastage_list')
    else:
        form = WastageForm()
    return render(request, 'wastage_form.html', {'form': form})

def wastage_update(request, pk):
    wastage = get_object_or_404(Wastage, pk=pk)
    if request.method == 'POST':
        form = WastageForm(request.POST, request.FILES, instance=wastage)
        if form.is_valid():
            form.save()
            return redirect('wastage_list')
    else:
        form = WastageForm(instance=wastage)
    return render(request, 'wastage_form.html', {'form': form})

# JobNumber Views
def job_number_list(request):
    job_numbers = Job_number.objects.all()
    return render(request, 'job_number_list.html', {'job_numbers': job_numbers})

def job_number_create(request):
    if request.method == 'POST':
        form = JobNumberForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('job_number_list')
    else:
        form = JobNumberForm()
    return render(request, 'job_number_form.html', {'form': form})

def job_number_update(request, pk):
    job_number = get_object_or_404(Job_number, pk=pk)
    if request.method == 'POST':
        form = JobNumberForm(request.POST, instance=job_number)
        if form.is_valid():
            form.save()
            return redirect('job_number_list')
    else:
        form = JobNumberForm(instance=job_number)
    return render(request, 'job_number_form.html', {'form': form})