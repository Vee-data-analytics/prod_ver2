# board_verification/__init__.py
default_app_config = 'board_verification.apps.BoardVerificationConfig'
